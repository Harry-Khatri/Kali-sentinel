#!/bin/bash

echo "[Kali Sentinel] Starting Threat Detection..."

# Run network scan
echo "[*] Running network scan module..."
bash $HOME/kali-sentinel/scripts/net_scan.sh

# Run packet capture
echo "[*] Running packet capture module..."
bash $HOME/kali-sentinel/scripts/packet_capture.sh

echo "[✓] Sentinel run complete. Check logs and pcap directories."
