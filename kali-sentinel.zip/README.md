
# Kali Sentinel

**Kali Sentinel** is a lightweight, script-based threat detection and response system using tools like Nmap and Wireshark.

## Features
- Subnet scanning with Nmap
- Differential analysis of network changes
- Packet capture (to be added)
- Logging and alert-ready structure

## Usage
1. Make scripts executable:
    chmod +x scripts/*.sh

2. Run a network scan:
    ./scripts/net_scan.sh
